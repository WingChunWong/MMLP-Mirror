```json
{
  "title": "粗灰泥台阶",
  "icon": "suppsquared:daub_slab",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/slabs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "suppsquared:daub_slab",
    "suppsquared:daub_frame_slab"
  ]
}
```

&spotlight(suppsquared:daub_slab)
**粗灰泥台阶**是[粗灰泥](^supplementaries:daub)的[台阶](^minecraft:tag/slabs)变种。

;;;;;

&title(Crafting)
<recipe;suppsquared:daub_slab>
<recipe;suppsquared:daub_frame_slab>
