---
navigation:
  title: 磨盘
  icon: "synergy:quern"
  parent: magic.md
  position: 2
categories:
  - magic
item_ids:
  - synergy:quern
---

# 磨盘

可以磨碎物品的功能方块。

同一时刻只能容纳一个物品堆叠。

使用物品右击即可将其放入磨盘。

磨盘没有GUI，但可用漏斗和类似物件自动化。

<ItemImage id="synergy:quern" scale="4.0"/>

<RecipeFor id="synergy:quern" />
