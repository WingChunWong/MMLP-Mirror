---
navigation:
  title: 烈焰金太阳能板
  icon: "justdynathings:blazegold_solar_panel"
  position: 2
  parent: justdynathings:solar_panels.md
item_ids:
  - justdynathings:blazegold_solar_panel
---

# 烈焰金太阳能板

会生产Forge能量（Forge Energy，FE）的太阳能板。

默认最大FE生产速率：**960**

**默认条件：**

- 维度 = 下界

<BlockImage id="justdynathings:blazegold_solar_panel" scale="4.0"/>

<Recipe id="justdynathings:blazegold_solar_panel" />

*注意：所有东西都可以用配置修改，不要轻信！*
