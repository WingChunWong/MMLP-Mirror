---
navigation:
  title: 农作物与蘑菇
  icon: "minecraft:sweet_berries"
  position: 4
categories:
  - main
---

# 农作物与蘑菇

有若干特殊特性的独特植物。

## 野生农作物

<CategoryIndex category="wild_crops"></CategoryIndex>

## 农作物

<CategoryIndex category="crops"></CategoryIndex>

## 蘑菇

<CategoryIndex category="mushrooms"></CategoryIndex>

## 植物盆栽

<CategoryIndex category="potted"></CategoryIndex>
