```json
{
  "title": "戒守护符",
  "icon": "trickster:warding_charm",
  "category": "trickster:items",
  "ordinal": 60
}
```

基础的魔法饰品，能够承载用作[戒守](^trickster:concepts/ward)的法术。

<recipe;trickster:warding_charm>
