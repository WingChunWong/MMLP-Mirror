本资源包是适用于 Minecraft 1.16.5 Fabric 的简体中文资源包，提供模组的简体中文本地化。

署名：CFPA团队（完整贡献者名单：https://github.com/CFPAOrg/Minecraft-Mod-Language-Package/graphs/contributors）

项目主页：https://cfpa.site/
参与贡献：https://cfpa.site/joinus.html
反馈问题：https://support.qq.com/product/382723
GitHub 仓库：https://github.com/CFPAOrg/Minecraft-Mod-Language-Package

如果你是手动下载的本资源包，欢迎使用 I18n Update Mod 模组自动下载安装资源包。

I18n Update Mod 下载方式有
MC百科：https://www.mcmod.cn/download/1188.html
CurseForge：https://www.curseforge.com/minecraft/mc-mods/i18nupdatemod
Modrinth：https://modrinth.com/mod/i18nupdatemod

本资源包中的部分帕秋莉手册翻译需安装帕秋莉手册加载补丁才能使用，下载地址：https://www.mcmod.cn/download/8906.html