---
navigation:
  title: 高级AE介绍
  position: 70
---

# 高级AE！

高级AE（Advanced AE）着眼于改善玩家管理ME系统的体验和拓展游戏的后期内容。本模组拥有能向特定面输出物品的样板供应器，只要有合成存储空间剩余就能运行无限个合成任务、共享并行处理器的多方块计算机，还有其他种种增进体验的额外内容！

![PEGui1](../pic/aae_intro.png)

本模组添加的方块与物品列表参见下方的指南页面：

## 高级设备

<CategoryIndex category="advanced devices"></CategoryIndex>

## 高级物品

<CategoryIndex category="advanced items"></CategoryIndex>

发现了漏洞？少了些特性？请在此处报告：[高级AE的GitHub](https://github.com/pedroksl/AdvancedAE)