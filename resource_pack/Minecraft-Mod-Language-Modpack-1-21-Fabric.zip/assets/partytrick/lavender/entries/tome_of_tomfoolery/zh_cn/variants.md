```json
{
  "title": "外形变种",
  "icon": "trickster:mirror_of_evaluation[minecraft:custom_model_data=2]",
  "category": "trickster:ploys",
  "additional_search_terms": [
    "虚荣之技巧",
    "自定义模型数据"
    ]
}
```

魔力本性反复无常、含混不清，而某些工具与魔力邻近，其物理形态也就具有了同样性质。此处提及的技巧术即可改变此类工具的外形，需指定槽位，且需其中物品可进行此类变化。不过，所有这些都是为了所谓&zwnj;*“潮流时尚”*。



由派对戏法（Party Trick）添加。

;;;;;

<|ploy@trickster:templates|trick-id=partytrick:set_custom_model_data,cost=1G|>

若指定数，则将物品相应进行美化变形，即修改擅长奥术之人口中所谓的“自定义模型数据”。数为0时会重置外形。