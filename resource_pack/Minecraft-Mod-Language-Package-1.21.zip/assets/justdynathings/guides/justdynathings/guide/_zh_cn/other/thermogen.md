---
navigation:
  title: 热力发电器
  icon: "justdynathings:thermo_generator"
  position: 6
  parent: justdynathings:other.md
item_ids:
  - justdynathings:thermo_generator
---

# 大地的力量

根据热源方块和流体冷却剂产生Forge能量（Forge Energy，FE）的新型发电机。

<BlockImage id="justdynathings:thermo_generator" scale="4.0" p:facing="down" p:active="true"/>

<Recipe id="justdynathings:thermo_generator" />

## 详细原理

FE生成 = 125 x 冷却剂效率 x 热源效率

流体mB消耗 = 125 / 冷却剂效率

*也许将来会简化*
