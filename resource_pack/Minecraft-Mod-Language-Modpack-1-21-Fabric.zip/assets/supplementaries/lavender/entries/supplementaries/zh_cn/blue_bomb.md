```json
{
  "title": "靛蓝炸弹",
  "icon": "supplementaries:bomb_blue",
  "categories": [
    "minecraft:items",
    "minecraft:group/combat"
  ],
  "associated_items": [
    "supplementaries:bomb_blue"
  ]
}
```

&spotlight(supplementaries:bomb_blue)
**靛蓝炸弹**是更为强力的[炸弹](^supplementaries:bomb)。


通常可在探险过程中于箱子中找到。

;;;;;

&title(用途)
靛蓝炸弹的爆炸能对实体造成较大的范围伤害，令它们着火，并给予它们虚弱效果。
靛蓝炸弹的爆炸能点燃附近的苦力怕。


靛蓝炸弹并不会在命中时就爆炸，而是会在撞到某物时闪光一次，给玩家留出时间反应，然后才会爆炸。
