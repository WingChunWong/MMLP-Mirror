---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 赛特斯石英块
  icon: quartz_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_block
---

# 赛特斯石英块

<BlockImage id="quartz_block" scale="8" />

用于存储<ItemLink id="certus_quartz_crystal" />的方块。可用于制造[赛特斯石英母岩](budding_certus.md)和[赛特斯石英装饰方块](decorative_certus.md)。

## 配方

<RecipeFor id="quartz_block" />
