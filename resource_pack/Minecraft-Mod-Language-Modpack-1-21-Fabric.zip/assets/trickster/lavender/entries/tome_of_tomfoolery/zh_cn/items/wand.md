```json
{
  "title": "魔杖",
  "icon": "trickster:wand",
  "category": "trickster:items",
  "ordinal": 30
}
```

魔杖是一件相当简单的魔法工具，手持右击时其会施放抄入其中的法术。

<recipe;trickster:wand>

可通过[记事员之技巧](^trickster:tricks/basic#4)向魔杖抄入法术。
