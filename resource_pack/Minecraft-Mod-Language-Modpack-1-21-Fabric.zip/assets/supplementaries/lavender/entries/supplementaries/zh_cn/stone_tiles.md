```json
{
  "title": "石瓦",
  "icon": "supplementaries:stone_tile",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:stone_tile"
  ]
}
```

&spotlight(supplementaries:stone_tile)
**石瓦**是[石头](^minecraft:stone)的装饰性变种。

;;;;;

&title(合成)
<recipe;supplementaries:stone_tile>
<recipe;supplementaries:stonecutting/stone_tile>

;;;;;

&title(合成材料)
<recipe;supplementaries:stone_tile_slab>
<recipe;supplementaries:stone_tile_stairs>

;;;;;

&title(烧炼材料)
<recipe;supplementaries:stone_tile_wall>


;;;;;

&title(切石材料)
<recipe;supplementaries:stonecutting/stone_tile_slab>
<recipe;supplementaries:stonecutting/stone_tile_stairs_from_bricks>
<recipe;supplementaries:stonecutting/stone_tile_wall_from_bricks>
