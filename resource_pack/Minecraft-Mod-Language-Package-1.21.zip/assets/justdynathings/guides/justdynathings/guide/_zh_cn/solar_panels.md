---
navigation:
  title: 太阳能板
  icon: "justdynathings:blazegold_solar_panel"
  position: 4
---

# 太阳的力量

会根据所处环境生成Forge能量（Forge Energy）的全新发电器。

<SubPages />
