```json
{
  "title": "法术谐振器",
  "icon": "trickster:spell_resonator",
  "category": "trickster:items",
  "ordinal": 140
}
```

一件简单的设备，能向所依附的方块发出任意强度的红石信号。


可分别通过[谐振之技巧](^trickster:ploys/block#12)和[谐振之辑流](^trickster:delusions_ingresses/block#5)配置与查询其红石信号。

;;;;;

<recipe;trickster:spell_resonator>
