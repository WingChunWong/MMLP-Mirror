---
navigation:
  title: 高级时间手杖
  icon: "justdynathings:advanced_time_wand"
  position: 1
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:advanced_time_wand
---

# 高级时间手杖

<ItemLink id="justdirethings:time_wand"/>的升级版，容量更大，且其点击功能有多种配置模式。

默认模式：

_可在配置文件中修改和禁用！_

- 正常：

与普通的<ItemLink id="justdirethings:time_wand"/>功能一致

- 2x加速：

一次点击相当于原先的2次 -> 4 > 16 > 64 > 256

- 4x加速：

一次点击相当于原先的4次 -> 16 > 256

- 最大：

一次点击相当于原先的8次，即一次达到256x

<ItemImage id="justdynathings:advanced_time_wand" scale="4.0"/>

<Recipe id="justdynathings:advanced_time_wand" />
