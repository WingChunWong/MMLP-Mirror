```json
{
  "title": "施法消耗",
  "icon": "minecraft:amethyst_shard",
  "category": "trickster:tricks",
  "required_advancements": [
    "trickster:cost_ploy"
  ],
  "secret": true,
  "additional_search_terms": [
    "消耗之技巧"
  ]
}
```

在收到多封来自魔术把戏股份有限公司总部关于本模组平衡性的投诉信后，我们决定正式实装物质层面上的法术消耗。


但是，玩家们的自由和选择权利也对我们至关重要。因此，本系统不作强制要求。

;;;;;

<|glyph@trickster:templates|trick-id=trickster:cost,title=消耗之技巧|>

->

---

消耗施法者物品栏中的一个紫水晶碎片。若无则产生失策。
