---
navigation:
  title: 高能凝胶
  icon: "justdynathings:energized_goo"
  parent: goo.md
  position: 1
categories:
  - goo
item_ids:
  - justdynathings:energized_goo
---

# 高能凝胶

需要**Forge能量**（Forge Energy）保持激活状态的新凝胶。

凝胶等级：**5**

<BlockImage id="justdynathings:energized_goo" scale="4.0" p:alive="false"/>
<BlockImage id="justdynathings:energized_goo" scale="4.0" p:alive="true"/>

<RecipeFor id="justdynathings:energized_goo" />
