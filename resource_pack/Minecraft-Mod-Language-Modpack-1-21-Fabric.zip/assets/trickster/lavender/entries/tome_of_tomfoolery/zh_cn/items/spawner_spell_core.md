```json
{
  "title": "磨难法术核心",
  "icon": "trickster:spawner_spell_core",
  "category": "trickster:items",
  "required_advancements": [
    "trickster:spawner_spell_core"
  ],
  "ordinal": 150
}
```

[法术核心](^trickster:items/spell_core)的一种，由刷怪笼驱动。它施法的速度是玩家施法的一又二分之一倍。不过，如果16格内没有玩家，它就会停止运作。
