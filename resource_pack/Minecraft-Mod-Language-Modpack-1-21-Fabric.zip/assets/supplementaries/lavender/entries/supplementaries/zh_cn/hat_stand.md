```json
{
  "title": "帽架",
  "icon": "supplementaries:hat_stand",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:hat_stand"
  ]
}
```

&spotlight(supplementaries:hat_stand)
**帽架**与盔甲架类似，但只能摆放头部装备。


空手对其<keybind;key.sneak>+<keybind;key.use>可摇晃帽架。

;;;;;

&title(合成)
<recipe;supplementaries:hat_stand>
