```json
{
  "title": "回响晶结",
  "icon": "trickster:echo_knot",
  "category": "trickster:items",
  "required_advancements": [
    "trickster:echo_knot"
  ],
  "ordinal": 20
}
```

只消单个碎片，就能制成两个[晶结](^trickster:items/knots)，容量相当于钻石晶结的两倍，自然充能速率更是其三倍：回响晶结已堪称超凡脱俗。但这并非它们真正的独特之处。源自同一回响碎片的两个晶结共享一个魔力储库。无论两者在什么地方，将其中一个填满，它的孪生晶结也将被填满。

;;;;;

TODO：解释消息行为
