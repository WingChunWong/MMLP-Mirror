```json
{
  "title": "灯",
  "icon": "supplementaries:stone_lamp",
  "parent": "minecraft:group/functional_blocks"
}
```

**灯**是会发光的[功能方块](^minecraft:group/functional_blocks)。