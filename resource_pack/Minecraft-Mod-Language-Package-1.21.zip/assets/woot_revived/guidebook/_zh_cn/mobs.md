---
navigation:
    title: "生物（该页面可能会导致卡顿）"
    position: 60
    icon: minecraft:spawner
---
# 生物（该页面可能会导致卡顿）

可在此处查看所有可被模拟的实体列表，及其最低工厂等级需求。

* [铜](mobs.md#copper)
* [铁](mobs.md#iron)
* [金](mobs.md#gold)
* [钻石](mobs.md#diamond)
* [下界合金](mobs.md#netherite)

# 铜

<TierMobs tier="tier_1" />

# 铁

<TierMobs tier="tier_2" />

# 金

<TierMobs tier="tier_3" />

# 钻石

<TierMobs tier="tier_4" />

# 下界合金

<TierMobs tier="tier_5" />