---
navigation:
  title: 自动化
  icon: "synergy:harvester"
  position: 5
categories:
  - main
---

# 自动化

可用于自动化的、有独特特性的功能方块。

<CategoryIndex category="automation"></CategoryIndex>
