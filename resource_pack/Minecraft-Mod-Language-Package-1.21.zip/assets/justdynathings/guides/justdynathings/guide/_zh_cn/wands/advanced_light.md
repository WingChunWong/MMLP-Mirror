---
navigation:
  title: 高级光源手杖
  icon: "justdynathings:advanced_light_wand"
  position: 6
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:advanced_light_wand
---

# 要有光！第二部分

功能与<ItemLink id="justdynathings:light_wand"/>相同，但每次使用消耗的是FE。

<ItemImage id="justdynathings:advanced_light_wand" scale="4.0"/>

<Recipe id="justdynathings:advanced_light_wand" />
