```json
{
  "title": "细木堆楼梯",
  "icon": "supplementaries:fine_wood_stairs",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/stairs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:fine_wood_stairs"
  ]
}
```

&spotlight(supplementaries:fine_wood_stairs)
**细木堆楼梯**是[细木堆](^supplementaries:fine_wood)的[楼梯](^minecraft:tag/stairs)变种。

;;;;;

&title(合成)
<recipe;supplementaries:fine_wood_stairs>
