---
navigation:
  title: 更多砧
  icon: "justdynathings:eclipse_alloy_anvil"
  position: 2
---

# 更多砧

不耗经验就能修复物品的特殊砧。

<SubPages />
