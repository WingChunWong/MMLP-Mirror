```json
{
  "title": "转译",
  "icon": "minecraft:redstone"
}
```

转译器的工作方式，以及相关特性的详细介绍。