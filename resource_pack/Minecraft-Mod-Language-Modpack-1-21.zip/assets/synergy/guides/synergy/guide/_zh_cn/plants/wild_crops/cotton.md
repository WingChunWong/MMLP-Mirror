---
navigation:
  title: 野生棉花
  icon: "synergy:wild_cotton"
  parent: plants.md
  position: 12
categories:
  - wild_crops
item_ids:
  - synergy:wild_cotton
---

# 野生棉花

生成于主世界的灌木，会掉落<ItemLink id="synergy:cotton_seed"/>。

<BlockImage id="synergy:wild_cotton" scale="4.0"/>

### 植物属性

| 右击收获                          | 可用骨粉催熟                      | 会扩散                            | 光照等级                           | 生成位置     |
| --------------------------------- | --------------------------------- | --------------------------------- | ---------------------------------- | ------------ |
| <Color color="#ff0000">否</Color> | <Color color="#ff0000">否</Color> | <Color color="#ff0000">否</Color> | <Color color="#ffff00">NaN</Color> | 任意森林     |
|                                   |                                   |                                   |                                    | 任意平原     |
|                                   |                                   |                                   |                                    | 任意热带草原 |
|                                   |                                   |                                   |                                    | 任意针叶林   |
