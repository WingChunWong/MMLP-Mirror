---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "战利品输出口"
    icon: "woot_revived:export"
---
# 战利品输出口

<BlockImage id="export" scale="5" p:attached="true" />

<ItemImage id="export" scale="0.5"/>战利品输出口是生物产出物品/流体的输出端

需将箱子或储罐与其相邻放置，来获得物品或流体。

管道对该方块不起作用！

## 合成

<RecipeFor id="export" />