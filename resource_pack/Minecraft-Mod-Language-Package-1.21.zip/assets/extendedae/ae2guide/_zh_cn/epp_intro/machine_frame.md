---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 扩展机器框架
    icon: extendedae:machine_frame
categories:
- extended foundation
item_ids:
- extendedae:machine_frame
---

# AE2扩展的起点

<Row>
<BlockImage id="extendedae:machine_frame" scale="8"></BlockImage>
</Row>

攒到足够的<ItemLink id="extendedae:entro_crystal" />后，就可着手合成第一个扩展机器框架了。这些框架是AE2扩展的基石，本模组中绝大多数的方块型机器都需用它合成。
