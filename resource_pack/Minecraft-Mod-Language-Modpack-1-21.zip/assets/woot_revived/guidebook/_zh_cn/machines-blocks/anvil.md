---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "幽冥砧"
    icon: "woot_revived:stygian_anvil"
---
# 幽冥砧

<BlockImage id="stygian_anvil" scale="5"/>

<ItemImage id="stygian_anvil" scale="0.5"/>幽冥砧是Woot：重生模组旅途的起点

要使用该方块进行合成，你需要使用<ItemImage id="stygian_hammer" scale="0.5"/>幽冥锤对其右击。更多信息可查看[入门起步](../getting-started.md)

空手对幽冥砧Shift右击，可取回物品

可使用物品管道，以及能够使用<ItemImage id="stygian_hammer" scale="0.5"/>幽冥锤对方块右击的装置来自动化幽冥砧

## 合成

<RecipeFor id="stygian_anvil" />