---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 电路切片器
    icon: extendedae:circuit_cutter
categories:
- extended devices
item_ids:
- extendedae:circuit_cutter
---

# 电路切片器

<Row gap="20">
<BlockImage id="extendedae:circuit_cutter" scale="8"></BlockImage>
</Row>

忍不了压印器缓慢的加工速度？欢迎使用电路切片器！它可以将块状的材料直接切割为[电路板](ae2:items-blocks-machines/processors.md)，大多数情况下，其速度都相当于压印器的9倍。

**注意，未配备接口的玻璃侧不提供网络连接。**

