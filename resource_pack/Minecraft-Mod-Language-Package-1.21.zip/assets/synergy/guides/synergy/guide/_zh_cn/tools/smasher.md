---
navigation:
  title: 快拆器
  icon: "synergy:smasher"
  parent: tools.md
  position: 4
categories:
  - tools
item_ids:
  - synergy:smasher
---

# 快拆器

一种工具，潜行时能瞬间破坏带有&zwnj;**#synergy:mashable**&zwnj;标签的方块。

<ItemImage id="synergy:smasher" scale="4.0"/>

<RecipeFor id="synergy:smasher" />
