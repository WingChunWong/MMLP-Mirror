```json
{
  "title": "燧石块",
  "icon": "supplementaries:flint_block",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:flint_block"
  ]
}
```

&spotlight(supplementaries:flint_block)
**燧石块**是装饰性与存储方块，也是手头多余燧石的好去处。

<block;supplementaries:flint_block>

;;;;;

&title(合成)
<recipe;supplementaries:flint_block>

;;;;;

&title(用途)
燧石块被活塞推动时，其会摩擦相邻面完整的铁块及类似方块，并产生火花。


附近的可燃方块会着火！相当于一个无耐久度损耗的随带随用打火石。

;;;;;

&title(用途)
让铁块移动，燧石块不动也能打出火花。


穿戴铁靴子及类似物时在燧石块上行走，同样能打出火花。
