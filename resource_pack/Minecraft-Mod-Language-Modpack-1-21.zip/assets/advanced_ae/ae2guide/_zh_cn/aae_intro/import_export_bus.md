---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: 输入输出总线
  icon: advanced_ae:import_export_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:import_export_bus_part
---

# 输入输出总线

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_import_export_bus.snbt"></ImportStructure>
</GameScene>

输入输出总线综合了<ItemLink id="ae2:import_bus" />与<ItemLink id="ae2:export_bus" />的功能。过滤器可设置为配置输出物品组，所有不在其中的物品均接受输入。